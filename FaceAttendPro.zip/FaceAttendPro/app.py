import cv2, os, joblib, numpy as np, pandas as pd, threading
from flask import Flask, render_template, Response, request, redirect, url_for, send_file, session
from datetime import datetime
from train import train_model 

app = Flask(__name__)
app.secret_key = 'smart_attendance_key_2026'

# --- CONFIG ---
DATAFOLDER = 'static/dataset'
MODEL_PATH = 'static/models/face_recognition_model.pkl'
CREDS_FILE = 'static/teacher_credentials.csv'

# Load Classifiers
face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')

# --- LIGHTING ROBUSTNESS SETUP ---
# CLAHE helps the AI see in uneven lighting (shadows vs bright spots)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

blink_status = {}

def log_attendance(name, mood):
    today = datetime.now().strftime("%Y-%m-%d")
    time_now = datetime.now().strftime("%H:%M:%S")
    if not os.path.exists('Attendance'): os.makedirs('Attendance')
    file_path = f'Attendance/Attendance-{today}.csv'
    
    if not os.path.exists(file_path):
        pd.DataFrame(columns=['Name', 'Time', 'Mood']).to_csv(file_path, index=False)
    
    df = pd.read_csv(file_path)
    if name not in df['Name'].values:
        new_entry = pd.DataFrame({'Name': [name], 'Time': [time_now], 'Mood': [mood]})
        pd.concat([df, new_entry], ignore_index=True).to_csv(file_path, index=False)

def gen_frames():
    camera = cv2.VideoCapture(0)
    while True:
        success, frame = camera.read()
        if not success: break
        
        # --- PREPROCESSING START ---
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # UPDATED: Replaced basic equalizeHist with CLAHE for better environmental robustness
        processed_gray = clahe.apply(gray) 
        # --- PREPROCESSING END ---
        
        # Use processed_gray for higher detection accuracy in shadows
        faces = face_cascade.detectMultiScale(processed_gray, 1.3, 10, minSize=(100, 100))
        
        for (x, y, w, h) in faces:
            current_name, mood, box_color = "Unknown", "Neutral", (255, 255, 255)
            
            # ROI should also use the enhanced grayscale for feature detection
            roi_gray = processed_gray[y:y+h, x:x+w]
            
            # 1. Focus Detection (Eyes)
            eyes = eye_cascade.detectMultiScale(roi_gray, 1.1, 10)
            
            # 2. Engagement Detection (Smile)
            roi_smile = roi_gray[h//2:h, :] 
            smiles = smile_cascade.detectMultiScale(roi_smile, 1.5, 20, minSize=(25, 25))
            
            # --- STATUS LOGIC ---
            if len(eyes) < 2:
                mood = "Distracted"
                box_color = (0, 165, 255) 
            elif len(smiles) > 0:
                mood = "Engaged"
                box_color = (0, 255, 0)
            else:
                mood = "Neutral"
                box_color = (255, 255, 255)

            try:
                if os.path.exists(MODEL_PATH):
                    model = joblib.load(MODEL_PATH)
                    face_img = cv2.resize(roi_gray, (50, 50)).flatten().reshape(1, -1)
                    probs = model.predict_proba(face_img)
                    
                    if np.max(probs) > 0.6: 
                        full_id = model.predict(face_img)[0]
                        current_name = full_id.split('_')[0]
                        
                        # 3. Liveness Check (Blink Event)
                        if len(eyes) == 0:
                            blink_status[full_id] = True
                            box_color = (0, 255, 255)
                        
                        if blink_status.get(full_id):
                            log_attendance(full_id, mood)
                            current_name = f"{current_name} (VERIFIED)"
                            if mood != "Distracted":
                                box_color = (0, 255, 0)
                            else:
                                box_color = (0, 165, 255)
            except:
                pass

            # Drawing on 'frame' (color) so the user sees a natural image
            cv2.rectangle(frame, (x, y), (x+w, y+h), box_color, 2)
            cv2.putText(frame, f"{current_name} | {mood}", (x, y-10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, box_color, 2)

        ret, buffer = cv2.imencode('.jpg', frame)
        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

# --- ROUTES REMAIN THE SAME ---
@app.route('/')
def index(): return render_template('index.html')

@app.route('/video_feed')
def video_feed(): return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        userid = request.form.get('userid', "")
        password = request.form.get('password', "")
        if password and os.path.exists(CREDS_FILE):
            df = pd.read_csv(CREDS_FILE)
            match = df[(df['username'].astype(str) == str(userid)) & (df['password'].astype(str) == str(password))]
            if not match.empty:
                session['teacher_name'] = match.iloc[0]['name']
                return redirect(url_for('teacher_portal'))
        student_dir = os.path.join(DATAFOLDER, 'Student')
        if os.path.exists(student_dir) and userid:
            for folder in os.listdir(student_dir):
                if str(userid) in folder:
                    session['student_id'] = folder
                    session['student_display_name'] = folder.split('_')[0]
                    return redirect(url_for('student_portal'))
        return "<h1>Invalid Credentials</h1>"
    return render_template('login.html')

@app.route('/get_logs')
def get_logs():
    path = f'Attendance/Attendance-{datetime.now().strftime("%Y-%m-%d")}.csv'
    if os.path.exists(path):
        df = pd.read_csv(path)
        logs = df.tail(5).copy()
        logs['Name'] = logs['Name'].apply(lambda x: x.split('_')[0])
        return {"logs": logs.to_dict('records'), "total": len(df['Name'].unique())}
    return {"logs": [], "total": 0}

@app.route('/register')
def register(): return render_template('register.html')

@app.route('/add_user', methods=['POST'])
def add_user():
    name, userid, role = request.form['name'], request.form['userid'], request.form['role']
    if role == 'Teacher':
        pwd = request.form.get('password')
        df_new = pd.DataFrame([[userid, pwd, name]], columns=['username', 'password', 'name'])
        if not os.path.exists(CREDS_FILE): df_new.to_csv(CREDS_FILE, index=False)
        else: df_new.to_csv(CREDS_FILE, mode='a', header=False, index=False)
    upath = os.path.join(DATAFOLDER, role, f"{name}_{userid}")
    if not os.path.exists(upath): os.makedirs(upath)
    cam = cv2.VideoCapture(0)
    count = 0
    while count < 25:
        ret, frame = cam.read()
        if ret:
            # Also apply basic processing during registration for better training data
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            enhanced = clahe.apply(gray)
            fs = face_cascade.detectMultiScale(enhanced, 1.3, 5)
            for (x, y, w, h) in fs:
                count += 1
                cv2.imwrite(f"{upath}/{name}_{count}.jpg", enhanced[y:y+h, x:x+w])
        if count == 25: break
    cam.release()
    threading.Thread(target=train_model).start()
    return redirect(url_for('index'))

@app.route('/student_portal')
def student_portal():
    if 'student_id' not in session: return redirect(url_for('login'))
    sid, sname = session['student_id'], session['student_display_name']
    search_id = sid.split('_')[-1]
    attendance_dir = 'Attendance'
    if not os.path.exists(attendance_dir): os.makedirs(attendance_dir)
    files = sorted([f for f in os.listdir(attendance_dir) if f.endswith('.csv')])
    history, present = [], 0
    for f in files:
        df = pd.read_csv(os.path.join(attendance_dir, f))
        matches = df[df['Name'].astype(str).str.contains(search_id)]
        if not matches.empty:
            present += 1
            history.append({"date": f[11:-4], "time": matches.iloc[0]['Time']})
    percent = round((present / len(files)) * 100, 2) if files else 0
    return render_template('student_portal.html', name=sname, percent=percent, ratio=f"{present}/{len(files)}", history=history)

@app.route('/teacher_portal')
def teacher_portal():
    if 'teacher_name' not in session: return redirect(url_for('login'))
    tname = session['teacher_name']
    attendance_dir = 'Attendance'
    if not os.path.exists(attendance_dir): os.makedirs(attendance_dir)
    files = sorted([f for f in os.listdir(attendance_dir) if f.endswith('.csv')])
    total, present_t, stats = len(files), 0, {}
    for f in files:
        df = pd.read_csv(os.path.join(attendance_dir, f))
        for n in set(df['Name'].tolist()):
            if n.startswith(tname): present_t += 1
            else: stats[n] = stats.get(n, 0) + 1
    report = [{"name": str(n).split('_')[0], "ratio": f"{c}/{total}", "percent": round((c/total)*100, 2)} for n, c in stats.items()]
    return render_template('teacher_portal.html', teacher_name=tname, my_percent=int((present_t/total)*100) if total else 0, my_ratio=f"{present_t}/{total}", report=report)

@app.route('/download')
def download():
    path = f"Attendance/Attendance-{datetime.now().strftime('%Y-%m-%d')}.csv"
    return send_file(path, as_attachment=True) if os.path.exists(path) else "File missing"

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
    