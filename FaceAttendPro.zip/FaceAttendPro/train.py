import os, cv2, joblib, numpy as np
from sklearn.neighbors import KNeighborsClassifier

def train_model():
    DATAFOLDER = 'static/dataset'
    MODEL_DIR = 'static/models'
    if not os.path.exists(MODEL_DIR): os.makedirs(MODEL_DIR)

    faces = []
    labels = []

    for role in ['Student', 'Teacher']:
        role_path = os.path.join(DATAFOLDER, role)
        if not os.path.exists(role_path): continue
        
        for user_folder in os.listdir(role_path):
            user_path = os.path.join(role_path, user_folder)
            label_name = user_folder 
            
            for img_name in os.listdir(user_path):
                img = cv2.imread(os.path.join(user_path, img_name), cv2.IMREAD_GRAYSCALE)
                if img is not None:
                    # Fix: Ensure all images are exactly the same size
                    img_resized = cv2.resize(img, (50, 50))
                    faces.append(img_resized.flatten())
                    labels.append(label_name)

    if len(faces) > 0:
        try:
            # n_neighbors=5 provides stability against flickering
            knn = KNeighborsClassifier(n_neighbors=5, algorithm='ball_tree')
            knn.fit(np.array(faces), np.array(labels))
            joblib.dump(knn, os.path.join(MODEL_DIR, 'face_recognition_model.pkl'))
            print("Successfully updated the AI model.")
        except Exception as e:
            print(f"Training failed: {e}")